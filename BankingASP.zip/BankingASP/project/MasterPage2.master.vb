﻿
Partial Class project_MasterPage2
    Inherits System.Web.UI.MasterPage
End Class

