﻿
Imports System.Data.SqlClient

Partial Class pages_Login
    Inherits System.Web.UI.Page

    Dim cn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\chauh\OneDrive\Documents\Visual Studio 2022\Programe\BankingASP\App_Data\BankDataBase.mdf;Integrated Security=True")
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            cn.Open()
            Dim str As String

            str = "select * from register where email = @email"
            Dim cmd As New SqlCommand(str, cn)
            cmd.Parameters.AddWithValue("@email", email.Text)
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader()
            If dr.Read() Then
                If dr("passWord").ToString = pass.Text Then
                    MsgBox("Login Successfully")
                    Response.Redirect("/pages/Home_Page.aspx")
                End If
                MsgBox("Invalid Password")
            End If
            MsgBox("Invalid Email")
            cn.Close()

        Catch ex As Exception

        End Try
        email.Text = ""
        pass.Text = ""

    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Response.Redirect("/pages/Register.aspx")
    End Sub
End Class
