﻿Imports System.Activities.Statements
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.Web.UI.WebControls.Expressions

Partial Class pages_CreditCard
    Inherits System.Web.UI.Page
    Dim stat As String
    Dim gndr As String


    Dim cn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\BankDataBase.mdf;Integrated Security=True")
    Protected Sub Button5_Click(sender As Object, e As EventArgs) Handles submit.Click
        Try

            cn.Open()

            Dim str As String
            str = "Insert into CreditCard (CardUsage,IntUse,CardType,FName,MName,LName,FthrName,Age,Mstatus,Gender,addr,NameOnCard,Image,Pnum,Dependents,Vehicle,quali,dob,panNum,AdhrNum)  values (@CardUsage,@IntUse,@CardType,@FName,@MName,@LName,@FthrName,@Age,@Mstatus,@Gender,@addr,@NameOnCard,@Image,@Pnum,@Dependents,@Vehicle,@quali,@dob,@panNum,@AdhrNum)"
            Dim cmd As New SqlCommand(str, cn)
            cmd.Parameters.AddWithValue("@CardUsage", CardUsage.Text)
            cmd.Parameters.AddWithValue("@IntUse", IntUse.Text)
            cmd.Parameters.AddWithValue("@CardType", CardType.Text)
            cmd.Parameters.AddWithValue("@FName", Fname.Text)
            cmd.Parameters.AddWithValue("@MName", Mname.Text)
            cmd.Parameters.AddWithValue("@LName", Lname.Text)
            cmd.Parameters.AddWithValue("@FthrName", Fthrname.Text)
            cmd.Parameters.AddWithValue("@Age", age.Text)
            cmd.Parameters.AddWithValue("@Mstatus", stat)
            cmd.Parameters.AddWithValue("@Gender", gndr)
            cmd.Parameters.AddWithValue("@addr", address.Text)
            cmd.Parameters.AddWithValue("@NameOnCard", NameOncarde.Text)
            cmd.Parameters.AddWithValue("@Image", FileUpload.PostedFile.InputStream)
            cmd.Parameters.AddWithValue("@Pnum", telnum.Text)
            cmd.Parameters.AddWithValue("@Dependents", dependents.Text)
            cmd.Parameters.AddWithValue("@Vehicle", vehicle.Text)
            cmd.Parameters.AddWithValue("@quali", edu.Text)
            cmd.Parameters.AddWithValue("@dob", dob.Text)
            cmd.Parameters.AddWithValue("@panNum", pan.Text)
            cmd.Parameters.AddWithValue("@AdhrNum", Aadhar.Text)

            cmd.ExecuteNonQuery()

            MsgBox("Inserted Successfully")
            cn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        CardUsage.Text = ""
        IntUse.Text = ""
        CardType.Text = ""
        Fname.Text = ""
        Mname.Text = ""
        Lname.Text = ""
        Fthrname.Text = ""
        age.Text = ""
        Yes.Checked = False
        No.Checked = False
        male.Checked = False
        female.Checked = False
        address.Text = ""
        NameOncarde.Text = ""
        telnum.Text = ""
        dependents.Text = ""
        vehicle.Text = ""
        edu.Text = ""
        dob.Text = ""
        pan.Text = ""
        Aadhar.Text = ""

    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Response.Redirect("Home_Page.aspx")
    End Sub

    Protected Sub Yes_CheckedChanged(sender As Object, e As EventArgs) Handles Yes.CheckedChanged
        stat = "Yes"
    End Sub

    Protected Sub No_CheckedChanged(sender As Object, e As EventArgs) Handles No.CheckedChanged
        stat = "No"
    End Sub

    Protected Sub male_CheckedChanged(sender As Object, e As EventArgs) Handles male.CheckedChanged
        gndr = "Male"
    End Sub

    Protected Sub female_CheckedChanged(sender As Object, e As EventArgs) Handles female.CheckedChanged
        gndr = "Female"
    End Sub
End Class
