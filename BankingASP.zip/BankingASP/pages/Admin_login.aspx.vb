﻿
Imports System.Activities.Expressions

Partial Class pages_Admin_login
    Inherits System.Web.UI.Page


    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Response.Redirect("Home_Page.aspx")
    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            If "Admin" = userid.Text And "Admin" = password.Text Then
                Response.Redirect("/DataBase/DataBase.aspx")
                MsgBox("Login Successfully")

            End If
            MsgBox("Invalid User_ID Or Password")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        userid.Text = ""
        password.Text = ""
    End Sub
End Class
