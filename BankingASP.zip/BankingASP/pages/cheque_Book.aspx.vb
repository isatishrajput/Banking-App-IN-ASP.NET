﻿Imports System.Data.SqlClient
Imports System.Data
Partial Class pages_cheque_Book
    Inherits System.Web.UI.Page

    Dim cn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\BankDataBase.mdf;Integrated Security=True")
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles submitbtn.Click
        Try
            cn.Open()
            Dim str As String
            str = "insert into CBook (AccType,AccNum,BookCount,leaves) values (@acc,@num,@countt,@pages)"
            Dim cmd As New SqlCommand(str, cn)
            cmd.Parameters.AddWithValue("@acc", AccType.Text)
            cmd.Parameters.AddWithValue("@num", AccNum.Text)
            cmd.Parameters.AddWithValue("@countt", BCount.Text)
            cmd.Parameters.AddWithValue("@pages", Cleaves.Text)
            cmd.ExecuteNonQuery()

            MsgBox("Insertion Successfully")

            cn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

        AccType.ClearSelection()

        AccNum.Text = ""

        BCount.ClearSelection()

        Cleaves.ClearSelection()

        chkOk.Checked = False


    End Sub

    Protected Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles chkOk.CheckedChanged
        submitbtn.Enabled = chkOk.Checked
    End Sub
End Class
