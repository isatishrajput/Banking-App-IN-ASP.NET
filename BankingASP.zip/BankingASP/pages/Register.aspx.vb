﻿Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.Data

Partial Class Register
    Inherits System.Web.UI.Page

    Dim cn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\BankDataBase.mdf;Integrated Security=True")
    Protected Sub rgstr_Click(sender As Object, e As EventArgs) Handles rgstr.Click
        Dim obj As New Login

        Try
            cn.Open()
            Dim str As String
            Dim ans As Integer
            str = "Insert into register(username,email,mnumber,passWord) values(@username,@email,@mNumber,@passWord)"

            Dim cmd As New SqlCommand(str, cn)
            cmd.Parameters.AddWithValue("@username", username.Text)
            cmd.Parameters.AddWithValue("@email", email.Text)
            cmd.Parameters.AddWithValue("@mNumber", number.Text)
            cmd.Parameters.AddWithValue("@passWord", password.Text)
            ans = cmd.ExecuteNonQuery

            MsgBox("Registered Successfully", ans)
            Response.Redirect("/pages/Home_Page.aspx")
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
        cn.Close()
        username.Text = ""
        email.Text = ""
        number.Text = ""
        password.Text = ""

    End Sub

    Protected Sub signIn_Click(sender As Object, e As EventArgs) Handles signIn.Click
        Response.Redirect("/pages/Login.aspx")
    End Sub
End Class
