﻿
Partial Class pages_Home_Page
    Inherits System.Web.UI.Page

End Class
