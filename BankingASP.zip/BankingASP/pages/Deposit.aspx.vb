﻿Imports System.ComponentModel
Imports System.Data.SqlClient
Imports System.Runtime.CompilerServices
Imports System.ServiceModel.Dispatcher

Partial Class pages_Deposit
    Inherits System.Web.UI.Page
    Dim amount As String

    Dim cn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\BankDataBase.mdf;Integrated Security=True")
    Protected Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles Dcash.CheckedChanged
        amount = "cash"
    End Sub

    Protected Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles Dcheque.CheckedChanged
        amount = "cheque"
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles cash.Click

        Dim calc As Double

        calc = Integer.Parse(P2000.Text) * 2000
        A2000.Text = calc.ToString

        calc = Integer.Parse(P500.Text) * 500
        A500.Text = calc.ToString

        calc = Integer.Parse(P200.Text) * 200
        A200.Text = calc.ToString

        calc = Integer.Parse(P100.Text) * 100
        A100.Text = calc.ToString

        calc = Integer.Parse(P50.Text) * 50
        A50.Text = calc.ToString

        calc = Integer.Parse(P20.Text) * 20
        A20.Text = calc.ToString

        calc = Integer.Parse(P10.Text) * 10
        A10.Text = calc.ToString

        TotalP.Text = Integer.Parse(P2000.Text) + Integer.Parse(P500.Text) + Integer.Parse(P200.Text) + Integer.Parse(P100.Text) + Integer.Parse(P50.Text) + Integer.Parse(P20.Text) + Integer.Parse(P10.Text)
        TotalAmt.Text = Integer.Parse(A2000.Text) + Integer.Parse(A500.Text) + Integer.Parse(A200.Text) + Integer.Parse(A100.Text) + Integer.Parse(A50.Text) + Integer.Parse(A20.Text) + Integer.Parse(A10.Text)

        Try
            cn.Open()
            If amount = "cash" Then
                Dim str As String
                str = "Insert into depositCsh (AccNumOrCCNum,name,panNum,ctNum,type,P2000,P500,P200,P100,P50,P20,P10,TotalP,TotalAmt) values (@AccNumOrCCNum,@name,@panNum,@ctNum,@type,@P2000,@P500,@P200,@P100,@P50,@P20,@P10,@TotalP,@TotalAmt)"
                Dim cmd As New SqlCommand(str, cn)
                cmd.Parameters.AddWithValue("@AccNumOrCCNum", AccNumOrCCNum.Text)
                cmd.Parameters.AddWithValue("@name", name.Text)
                cmd.Parameters.AddWithValue("@panNum", panNum.Text)
                cmd.Parameters.AddWithValue("@ctNum", ctNum.Text)
                cmd.Parameters.AddWithValue("@type", amount)
                cmd.Parameters.AddWithValue("@P2000", P2000.Text)
                cmd.Parameters.AddWithValue("@P500", P500.Text)
                cmd.Parameters.AddWithValue("@P200", P200.Text)
                cmd.Parameters.AddWithValue("@P100", P100.Text)
                cmd.Parameters.AddWithValue("@P50", P50.Text)
                cmd.Parameters.AddWithValue("@P20", P20.Text)
                cmd.Parameters.AddWithValue("@P10", P10.Text)
                cmd.Parameters.AddWithValue("@TotalP", TotalP.Text)
                cmd.Parameters.AddWithValue("@TotalAmt", TotalAmt.Text)

                cmd.ExecuteNonQuery()

                MsgBox("Form Fill Successfully")
                cn.Close()
            End If
        Catch ex As Exception
            MsgBox("Invalid")
            MsgBox(ex.Message)
        End Try
    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles cheque.Click
        Try
            cn.Open()
            If amount = "cheque" Then
                Dim str As String
                str = "Insert into depositChq (AccNumOrCCNum,name,panNum,ctNum,type,chqNum,chqAmt) values (@AccNumOrCCNum,@name,@panNum,@ctNum,@type,@chqNum,@chqAmt)"
                Dim cmd As New SqlCommand(str, cn)
                cmd.Parameters.AddWithValue("@AccNumOrCCNum", AccNumOrCCNum.Text)
                cmd.Parameters.AddWithValue("@name", name.Text)
                cmd.Parameters.AddWithValue("@panNum", panNum.Text)
                cmd.Parameters.AddWithValue("@ctNum", ctNum.Text)
                cmd.Parameters.AddWithValue("@type", amount)
                cmd.Parameters.AddWithValue("@chqNum", chqNum.Text)
                cmd.Parameters.AddWithValue("@chqAmt", chqAmt.Text)

                cmd.ExecuteNonQuery()
                MsgBox("Form Deposit successfully")
                cn.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Protected Sub cash0_Click(sender As Object, e As EventArgs) Handles cash0.Click
        AccNumOrCCNum.Text = ""
        name.Text = ""
        panNum.Text = ""
        ctNum.Text = ""
        Dcash.Checked = False
        Dcheque.Checked = False
        chqNum.Text = ""
        chqAmt.Text = ""
        P2000.Text = ""
        P500.Text = ""
        P200.Text = ""
        P100.Text = ""
        P50.Text = ""
        P20.Text = ""
        P10.Text = ""
        A2000.Text = ""
        A500.Text = ""
        A200.Text = ""
        A100.Text = ""
        A50.Text = ""
        A20.Text = ""
        A10.Text = ""
        TotalP.Text = ""
        TotalAmt.Text = ""
    End Sub
End Class
