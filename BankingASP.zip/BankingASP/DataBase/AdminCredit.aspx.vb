﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class pages_AdminCredit
    Inherits System.Web.UI.Page

    Dim cn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\BankDataBase.mdf;Integrated Security=True")

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            cn.Open()
            Dim str As String

            str = "select * from CreditCard where AdhrNum = @adhr"
            Dim cmd As New SqlCommand(str, cn)
            cmd.Parameters.AddWithValue("@adhr", searchtxt.Text)
            Dim adp As New SqlDataAdapter(cmd)
            Dim filters As New DataTable()

            adp.Fill(filters)

            GridView1.DataSource = filters
            GridView1.DataSourceID = Nothing
            GridView1.DataBind()
            cn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            cn.Open()
            Dim selects As String = selectBox.SelectedValue

            Dim str As String
            str = "update CreditCard set " & selects & " = @value where AdhrNum = @adhr"
            Dim cmd As New SqlCommand(str, cn)
            cmd.Parameters.AddWithValue("@value", updatetxt.Text)
            cmd.Parameters.AddWithValue("@adhr", searchtxt.Text)
            Dim adp As New SqlDataAdapter(cmd)
            Dim filters As New DataTable()

            adp.Fill(filters)

            GridView1.DataSource = filters
            GridView1.DataSourceID = Nothing
            GridView1.DataBind()
            Response.Redirect("AdminCredit.aspx")
            cn.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        updatetxt.Text = ""
        selectBox.ClearSelection()
        searchtxt.Text = ""
    End Sub

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            cn.Open()

            Dim str As String
            str = "delete from CreditCard where AdhrNum = @adhr"
            Dim cmd As New SqlCommand(str, cn)

            cmd.Parameters.AddWithValue("@adhr", searchtxt.Text)
            Dim adp As New SqlDataAdapter(cmd)
            Dim filters As New DataTable()

            adp.Fill(filters)

            GridView1.DataSource = filters
            GridView1.DataSourceID = Nothing
            GridView1.DataBind()
            Response.Redirect("AdminCredit.aspx")
            cn.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
